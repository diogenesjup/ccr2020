$JSView.controller = {
    viewPrincipal: function(e){
		$JSView.dataView({},e)
	},
	viewPadroesInterface: function(e){
		$JSView.dataView({},e)
	},


	modalFavoritos: function(e){
		$JSView.dataView({},e)	
	}	

}
