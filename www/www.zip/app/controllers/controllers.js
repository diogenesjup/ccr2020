$JSView.controller = {
    home: function(e){
		$JSView.dataView({},e)
	},
	locais: function(e){
		$JSView.dataView({},e)
	},
	fretes: function(e){
		$JSView.dataView({},e)
	},
	single: function(e){
		$JSView.dataView({},e)
	},

}
